jQuery(document).ready(function($){
    // Определяем координаты верха блока навигации
  	$h = $('.scroll_nav').offset().top;
	$(window).scroll(function(){
        // Если прокрутили скролл ниже макушки блока, включаем фиксацию
		if ( $(window).scrollTop() > $h) {
        	$(".scroll_nav").css({"position":"fixed", "top":"0px"});
        }else{
            //Иначе возвращаем всё назад. Тут вы вносите свои данные
        	$(".scroll_nav").css({"position":"absolute", "top":"0px"});
        }
  });
});