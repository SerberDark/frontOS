$('.navbar-nav a').click(function( ){ 
        $(".navbar-collapse").removeClass("in");
        $(".navbar-toggle").addClass("collapsed");
        });