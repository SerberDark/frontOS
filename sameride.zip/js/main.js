jQuery(document).ready(function(){
	initValidate();
	initHeaderNavigation();
});

function initHeaderNavigation(){
	$('#menu').each(function(){		var hold = $(this);		var link = hold.find('a.navigation');
		var header = $('.header .scroll_nav');
		var hash = window.location.hash.split('#')[1];
		var flag = true;
		var top;
		if(hash){
			flag = false;
			top = $('#'+hash).offset().top - header.outerHeight(true);
			if(top < 0) top = 0;
			$('body, html').animate({scrollTop: top}, 1000, function(){
				flag = true;
			});
			
			
		}		link.click(function(){
			var _this = this;
			if(flag){
				flag = false;
				$('body, html').animate({scrollTop: $($(_this).attr('href')).offset().top -  header.outerHeight(true)}, 300, function(){
					flag = true;
					window.location.hash = $(_this).attr('href');
				});
			}
			return false;					});	});
}
function initValidate(){
	$('.send-form').each(function(){		var hold = $(this);		var input = hold.find('[data-name="required"]');
		var _time;
		var btn = hold.find('[type="submit"]');
		var flag = false;
		btn.on('click',function(event){
			event.preventDefault();
			
			if (checkField()) {
				$.ajax({
					type: 'POST',
					data: hold.serialize(),
					url: hold.attr('action'),
					success: function(msg){
						$('.hold-bth button[type="submit"]').animate({
							opacity: 0
						}, {
							queue: false,
							duration: 600,
							complete: function(){
								$(this).css({
									display: 'none'
								});
								$('.hold-bth  span.border-none').css({
									display: 'block'
								}).animate({
									opacity: 1
								}, {
									queue: false,
									duration: 600
								});
							}
						});
						
						if (_time) 
							clearTimeout(_time);
						_time = setTimeout(function(){
							$('.hold-bth  span.border-none').animate({
								opacity: 0
							}, {
								queue: false,
								duration: 600,
								complete: function(){
									$(this).css({
										display: 'none'
									});
									$('.hold-bth button[type="submit"]').css({
										display: 'block'
									}).animate({
										opacity: 1
									}, {
										queue: false,
										duration: 600
									});
								}
							});
							
							hold.trigger('reset');
						}, 2000);
						
					},
					error: function(){
						alert('Server is unavailable. Refresh the page within 15 seconds.!');
					}
				});
			}
		});
		input.each(function(){
			$(this).on('focus',function(){
				$(this).parent().removeClass('error');
			})
			
		});
		function checkField(){
			input.each(function(){
				if($(this).val() === ''){
					$(this).parent().addClass('error');
					flag = false;
				}
				else{
					flag = true;
				}			});
			
			return flag;
		}			});
}
